package stepik.javaweb1.lesson21.type;

public interface IdExistable {
    String MESSAGE_NULL_POINTER_EXEPTION = "Id does not exist";
    Long getId() throws NullPointerException;
    boolean isNull();
}
