package stepik.javaweb1.lesson21.type;

public interface LogExistable {
    String MESSAGE_NULL_POINTER_EXEPTION = "Login does not exist";
    String toString() throws NullPointerException;
    boolean isNull();
}
