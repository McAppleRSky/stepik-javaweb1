package stepik.javaweb1.lesson21.type;

public class User {
    String string;
}
