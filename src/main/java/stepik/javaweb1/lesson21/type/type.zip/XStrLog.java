package stepik.javaweb1.lesson21.type;



public class XStrLog<T> implements LogExistable {

    private String login = null;

    public XStrLog(String login) {
        this.login = login;
    }

    @Override
    public String toString() throws NullPointerException {
        if(login==null) throw new NullPointerException(MESSAGE_NULL_POINTER_EXEPTION);
        return login;
    }

    @Override
    public boolean isNull() {
        return login==null?true:false;
    }
}
