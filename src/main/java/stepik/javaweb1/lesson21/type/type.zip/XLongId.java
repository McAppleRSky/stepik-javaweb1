package stepik.javaweb1.lesson21.type;

import stepik.javaweb1.lesson21.type.plain.LongId;

public class XLongId<T> extends LongId implements IdExistable {

    private Long id = null;

    public XLongId(Long id) {
        super(id);
        this.id = super.getId();
    }

    @Override
    public Long getId() throws NullPointerException{
        if(id==null) throw new NullPointerException(MESSAGE_NULL_POINTER_EXEPTION);
        return id;
    }

    @Override
    public boolean isNull() {
        return id==null?true:false;
    }

}
